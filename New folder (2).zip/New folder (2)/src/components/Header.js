import React from 'react'

export const Header = () => {
    return (
        <h2>
            Saylani Expense Tracker
        </h2>
    )
}
